package com.kislytgbot.solution.YeelightBot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YeelightBotApplicationTests {

	@Test
	void contextLoads() {
	}

}
